﻿// See https://aka.ms/new-console-template for more information
// See https://aka.ms/new-console-template for more information


using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;

namespace poe;
public class POE
{
    List<string> RecipeName = new List<string>();
    Dictionary<string, string> Ingridients = new Dictionary<string, string>();//declaring the Dictionary collection for ingridient name
    Dictionary<string, double> Quantities = new Dictionary<string, double>();//declaring the Dictionary collection for ingridient Quantity 
    Dictionary<string, int> Measurements = new Dictionary<string, int>();//declaring the Dictionary collection for ingridient Measurements

    Dictionary<string, string> description = new Dictionary<string, string>();//declaring the Dictionary collection for ingridient Steps 
    Dictionary<string, string> units = new Dictionary<string, string>();//declaring the Dictionary collection for ingridient/measurements units
    Dictionary<string, int> calories = new Dictionary<string, int>();////declaring the Dictionary collection for ingridient calories
    Dictionary<string, string> FoodGroup = new Dictionary<string, string>();//declaring the Dictionary collection for ingridient 's Food group




    //declaring my variables 

    int engreNum;//declared  variable for my Ingridient loops
    double n;//declared  variable for my Ingridient loops
    int step;//declared variable for steps 
    String Q;

    Boolean m = true;

    string Ingridients1;//Declared variable for naming the Ingridients before storing them into the collections
    double Quantities1;//Declared variable for naming the Quantity before storing them into the collections
    int Measurements1;//Declared variable for naming the Measurements before storing them into the collections
    string description1;//Declared variable for naming the steps before storing them into the collections

    public delegate void Mycallories(String Message);// declared a  methord for delegate 

    public void EnterRecipe()//methord for entering recipe details 
    {
        int count = 1;
        string recipename;//Declared variable for naming the recipe before storing them into the arraylist
        Console.ForegroundColor = ConsoleColor.Green;//making the colour of this methord to green

        Console.WriteLine("Welcome ");
        Console.WriteLine("enter recipe name ");
        recipename = (Console.ReadLine());// user must input Recipe name
        RecipeName.Add(recipename);
        try//exception handling for the number of ingridients that are suppose to be entered 
        {
            Console.WriteLine("Enter  the number of ingridients you want to enter ");
            engreNum = int.Parse(Console.ReadLine());// user must enter the number of ingridients that she or he want to input
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Wrong input !! Please enter proper value");
            Console.WriteLine("Enter  the number of ingridients you want to enter ");
            engreNum = int.Parse(Console.ReadLine());// user must enter the number of ingridients that she or he want to input
            Console.ForegroundColor = ConsoleColor.Green;
        }

        int rr = 1;//declaring an int that will help to form dictionary key 
        int k = 1;
        int TotalCallories = 0;//declaring and assining a value that will hold and calculate total callories that have been entered 
        for (int i = 0; i < engreNum; i++)

           
        {

            string recipename1 = recipename;
            recipename1 = string.Concat(recipename, rr);//combining the name of the recipe and int rr to make a key that i will be able to call it by 

            Boolean p = true;//declaringg a boolean variable that will be used in a lop at the bottom to ensure that the user enters proper Quantity 

            Console.WriteLine("ingredient " + k + " name: ");
            Ingridients1 = (Console.ReadLine()); // user must input the ingredient

            Ingridients.Add(recipename1, Ingridients1);

            while (p)
            {
                try
                {
                    Console.WriteLine("ingredient Quantity");
                    Quantities1 = (int.Parse(Console.ReadLine()));//user must input the Quantity
                    Quantities.Add(recipename1, Quantities1);
                    break;
                }
                catch (Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;//changing the color to red 
                    Console.WriteLine("please input proper Quantity");
                }
            }


            Console.ForegroundColor = ConsoleColor.Green;//changing the color to red 
            Console.WriteLine("units of the ingredients measurements (mg),(g),(kg),(ml),(l),(teaspoon),(cup)");//user must enter Quantity units
            String units1 = Console.ReadLine();



            Boolean n = true;
            while (n)//loop that ensures that the user inputs the right units 
            {
                if (units1.Equals("mg"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("g"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("kg"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("ml"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("l"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("teaspoon"))
                {
                    units.Add(recipename1, units1);
                    break;
                }
                else if (units1.Equals("cup"))
                {
                    units.Add(recipename1, units1);
                    break;
                }

                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;//changing the color to red 
                    Console.WriteLine("Wrong units please enter again");
                    Console.WriteLine("units of the ingredients measurements (mg),(g),(kg),(ml),(l),(teaspoon),(cup)");
                    units1 = Console.ReadLine();
                    Console.ForegroundColor = ConsoleColor.Green;//changing the color to green 
                }


            }
            k++;

            rr++;

            Console.WriteLine("write the number of callories for this ingridient");
            int callories = int.Parse(Console.ReadLine());
            calories.Add(recipename1, callories);

            TotalCallories += callories;
            if (TotalCallories > 300)
            {
                Console.ForegroundColor = ConsoleColor.Red;//changing the color to red 
                Mycallories del = Callories;
                del("Total number of callories have exceeded 300  ");//this del calls a message when callories esceeds 300
            }
            Console.ForegroundColor = ConsoleColor.Green;//changing the color to green
            Console.WriteLine("Choose  the food group of the ingridients \n 1:Starchy foods\n 2:Vegetables and fruits \n 3:Dry beans, peas, lentils and soya \n 4:Chicken, fish, meat and eggs  \n 5:Milk and dairy products  \n6: Fats and oil \n 7:Water. ");
            int FoodG = int.Parse(Console.ReadLine());//user must choose the food group
            bool P = true;
            while (P)
            {
                if (FoodG == 1)
                {
                    string W = "Starchy Foods";
                    FoodGroup.Add(recipename1, W);
                    break;
                }
                else if (FoodG == 2)
                {
                    FoodGroup.Add(recipename1, "Vegetables and fruits");
                    break;
                }
                else if (FoodG == 3)
                {
                    FoodGroup.Add(recipename1, "Dry beans, peas, lentils and soya");
                    break;
                }
                else if (FoodG == 4)
                {
                    FoodGroup.Add(recipename1, "Chicken, fish, meat and eggs");
                    break;
                }
                else if (FoodG == 5)
                {
                    FoodGroup.Add(recipename1, "Milk and dairy products");
                    break;
                }
                else if (FoodG == 6)
                {
                    FoodGroup.Add(recipename1, "Fats and oil");
                    break;
                }
                else if (FoodG == 7)
                {
                    FoodGroup.Add(recipename1, "Water");
                    break;
                }

                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;//changing the color to red 
                    Console.WriteLine("Choose  the food group of the ingridients \n 1:Starchy foods\n 2:Vegetables and fruits \n 3:Dry beans, peas, lentils and soya \n 4:Chicken, fish, meat and eggs  \n 5:Milk and dairy products  \n 6:Fats and oil \n 7:Water. ");
                    FoodG = int.Parse(Console.ReadLine());
                }
            }

        }

        Console.WriteLine("num of steps ");
        int step = int.Parse(Console.ReadLine());// user must input the number of steps 

        int r2 = 1;
        for (int i = 0; i < step; i++)
        {


            string recipename1 = recipename;
            recipename1 = string.Concat(recipename, r2);

            Console.WriteLine("please enter  step " + count + " of the recipe");
            description1 = (Console.ReadLine());// user must enter the steps 
            description.Add(recipename1, description1);
            count++;
            r2++;

        }
    }
    public void view()//view methord .this methord allows the user to enter the name of the recipe that they want to view 
    {
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        RecipeName.Sort();
        foreach (string recipename in RecipeName)
        {
            Console.WriteLine($"{recipename}");
        }

        Console.WriteLine("Enter the Recipe Name you want to view ");
        String recipeName4 = Console.ReadLine();



        for (int i = 0; i < RecipeName.Count; i++)
        {
            Console.WriteLine("****************************************** ");
            String RecipeNAME1;
            String RecipeNAME2;
            int ll = 1;
            int k = 1;
            int r = 1;
            int TotalC = 0;


            if (recipeName4.Equals(RecipeName[i]))
            {
                Console.WriteLine(" Recipe : " + RecipeName[i]);

                for (int j = 0; j < Ingridients.Count; j++)
                {

                    RecipeNAME1 = string.Concat(RecipeName[i], ll);



                    if (Ingridients.ContainsKey(RecipeNAME1))
                    {
                        if (Quantities.ContainsKey(RecipeNAME1))
                        {

                            if (units.ContainsKey(RecipeNAME1))
                            {

                                Console.WriteLine(" ingridients : " + k);
                                Console.WriteLine(Ingridients[RecipeNAME1] + "  " + Quantities[RecipeNAME1] + "  " + units[RecipeNAME1]);

                                Console.WriteLine("Food group:" + FoodGroup[RecipeNAME1]);
                                Console.WriteLine("Callories :" + calories[RecipeNAME1]);


                                k++;

                                ll++;

                                TotalC += calories[RecipeNAME1];
                            }



                        }
                    }

                }
                Console.WriteLine("Total callories :" + TotalC);

                for (int x = 0; x < description.Count; x++)
                {


                    RecipeNAME2 = string.Concat(RecipeName[i], r);

                    if (description.ContainsKey(RecipeNAME2))
                    {
                        Console.WriteLine();
                        Console.WriteLine(" Steps ");


                        Console.WriteLine("step " + r + ":" + description[RecipeNAME2]);

                        r++;


                    }
                }

                Console.WriteLine("****************************************** ");
            }
            


        }

        //paste display 
    }
    public void Display()//methord to desplay the recipe steps and ingridients 
    {


        Console.ForegroundColor = ConsoleColor.DarkBlue;




        for (int i = 0; i < RecipeName.Count; i++)
        {
            Console.WriteLine("****************************************** ");
            String RecipeNAME1;
            String RecipeNAME2;
            int ll = 1;
            int k = 1;
            int r = 1;
            int TotalC = 0;



            Console.WriteLine(" Recipe : " + RecipeName[i]);

            for (int j = 0; j < Ingridients.Count; j++)
            {

                RecipeNAME1 = string.Concat(RecipeName[i], ll);



                if (Ingridients.ContainsKey(RecipeNAME1))
                {
                    if (Quantities.ContainsKey(RecipeNAME1))
                    {

                        if (units.ContainsKey(RecipeNAME1))
                        {

                            Console.WriteLine(" ingridients : " + k);
                            Console.WriteLine(Ingridients[RecipeNAME1] + "  " + Quantities[RecipeNAME1] + "  " + units[RecipeNAME1]);

                            Console.WriteLine("Food group:" + FoodGroup[RecipeNAME1]);
                            Console.WriteLine("Callories :" + calories[RecipeNAME1]);


                            k++;

                            ll++;

                            TotalC += calories[RecipeNAME1];
                        }
                    }
                }

            }
            Console.WriteLine("Total callories :" + TotalC);

            for (int x = 0; x < description.Count; x++)
            {


                RecipeNAME2 = string.Concat(RecipeName[i], r);

                if (description.ContainsKey(RecipeNAME2))
                {
                    Console.WriteLine();
                    Console.WriteLine(" Steps ");


                    Console.WriteLine("step " + r + ":" + description[RecipeNAME2]);

                    r++;
                }
            }

            Console.WriteLine("****************************************** ");

        }

    }


    public void ChangeQuantity() //methords that allow the user to change the quantity ....try catch 
    {


        Console.WriteLine("The name of the recipe you want to change quantity");
        Q = Console.ReadLine();

        Console.WriteLine("Choose the factor that you would like ingredients to be affected with: \n 1-0.5(half) \n2-2(double) \n3- 3(triple) \n");
        n = int.Parse(Console.ReadLine());
        for (int x = 0; x < RecipeName.Count; x++)
        {

            int LL = 1;

            for (int i = 0; i < Quantities.Count; i++)
            {

                string RecipeNAME3 = string.Concat(Q, LL);
                if (Quantities.ContainsKey(RecipeNAME3))
                {
                    if (Quantities[RecipeNAME3] == 8 && units[RecipeNAME3].Equals("teaspoon") && n == 2)
                    {
                        Quantities[RecipeNAME3] = 1;
                        units[RecipeNAME3] = "cup";
                    }
                    else if (n == 1)
                    {
                        Quantities[RecipeNAME3] *= 0.5;

                    }
                    else
                    {
                        Quantities[RecipeNAME3] *= n;

                    }
                    LL++;
                }
            }// if 8 spoon is  = 1 cup 
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(" Quantity changed ");
        }
    }


    public void Normal()//methord that makes resert the quantity to the origial one........ try
    {

        int LK  = 1;

        for (int i = 0; i < Quantities.Count; i++)
        {

            string RecipeNAME3 = string.Concat(Q, LK);
            if (Quantities[RecipeNAME3] == 1 && units[RecipeNAME3].Equals("cup") && n == 2)
            {
                Quantities[RecipeNAME3] = 8;
                units[RecipeNAME3] = "teaspoon";
            }
            else if (n == 1)
            {
                Quantities[RecipeNAME3] /= 0.5;

            }
            else
            {
                Quantities[RecipeNAME3] /= n;

            }
            LK++;
        }
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine(" Quantity changed ");

    }




    public void clear()//this methord clears the collections 
    {
        Ingridients.Clear();
        Quantities.Clear();
        RecipeName.Clear();
        Measurements.Clear();
        units.Clear();
        description.Clear();


    }
    static void Callories(String Message)
    {
        Console.WriteLine("  " + Message);
    }

}


public class poe
{
    public static void Main(String[] args)//main class
    {

        POE pOE = new POE();

        //   int l;
        while (true) 
        {
            //menu that makes the user to choose what he or she wants to do 
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************************************* ");
            Console.WriteLine("1.ADD Recipe ");
            Console.WriteLine("2.Display recipe  ");
            Console.WriteLine("3.Change Quantity ");
            Console.WriteLine("4.Clear your recipes  ");
            Console.WriteLine("5.Set normal Quantity ");
            Console.WriteLine("6.Choose recipe to view");
            Console.WriteLine("7.Done  ");
            Console.WriteLine("************************************************* ");
            int l = int.Parse(Console.ReadLine());




            switch (l)
            {
                // case 0:
                case 1:
                    pOE.EnterRecipe();//calls the  the recipe methord 


                    break;
                case 2:
                    pOE.Display();//calls the display methord 
                    break;
                case 3:
                    pOE.ChangeQuantity();//calls the change quantity methord 
                    break;
                case 4:
                    pOE.clear();//calls the clear methord 
                    break;
                case 5:
                    pOE.Normal();// calls the methord that returns the Quantity to normal 
                    break;
                case 6:
                    pOE.view();//calls the view methords 
                    break;
                case 7:
                default:
                    return;


            }


        }
        Console.WriteLine("************************************************* ");
        Console.WriteLine("Good bye ");


    }
}


class cal
{
    static void Callories(String Message)
    {
        Console.WriteLine("  " + Message);
    }
}
